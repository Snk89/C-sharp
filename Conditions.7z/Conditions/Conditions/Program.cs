﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditions
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Motor motor = new Motor();
        }
    }
}
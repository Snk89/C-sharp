﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerSoftware.CoreEngine
{
    internal class Salesman
    {
        //Atributos

        //Construtor

        //Save a estrutura de dados (recebe uma lista)

        //Reset da estrutura de dados

        //Get da Estrutura de dados

        //Ordena por id (ascendente)  - Utilizar o BubbleSort
        // É necessário converter os dados para um array, usar o BubbleSort e passá-los novamente (já ordenados) para uma lista

        //Método envio dos dados em forma de Lista
    }
}
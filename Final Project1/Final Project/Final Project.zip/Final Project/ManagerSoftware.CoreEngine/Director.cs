﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerSoftware.CoreEngine
{
    internal class Director
    {
        //Atributos

        //Construtor

        //Save a estrutura de dados (recebe uma lista)

        //Reset da estrutura de dados

        //Get da Estrutura de dados

        //filtra os mais recentes (desde 01/nov/2017)
        //List<Archive> filteredList = myqueue.Where(a => .......).ToList();

        //ordena a lista filtrada por nome - implementa o IComparable

        //Método envio dos dados em forma de Lista
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ManagerSoftware.CoreEngine
{
    public class Engine
    {
        //atributo funcionario;

        public Queue<Archive> InsertQueue(string name, string email, string contact, List<Archive> list)
        {
            //chama a função para criar o funcionario (Diretor/Operario) e associa-o ao atributo

            // devolve a estrutura de dados de Archive associada ao funcionario (p.e. funcionario.GetList())
            return new Queue<Archive>(list);
        }

        public Stack<Archive> InsertStack(string name, string email, string contact, List<Archive> list)
        {
            //chama a função para criar o funcionario (Diretor/Operario) e associa-o ao atributo

            // devolve a estrutura de dados de Archive associada ao funcionaario (p.e. funcionario.GetList())
            return new Stack<Archive>(list);
        }

        //cria diretor

        //cria operario

        public List<Archive> Send()
        {
            //chama o método send do funcionario e devolve a lista retomada
            return new List<Archive>();
        }

        public void Reset()
        {
            //Limpa a informação armazenada (i.e. atributos no Engine e no Funcionário)
        }
    }
}